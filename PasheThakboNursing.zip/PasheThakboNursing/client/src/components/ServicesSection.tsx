import React from "react";
import { Service } from "@/lib/types";

const ServicesSection: React.FC = () => {
  const services: Service[] = [
    {
      title: "Nursing Care",
      description: "Professional nursing services including medication management, wound care, vital signs monitoring, and more.",
      imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "Available 12/24 hours"
    },
    {
      title: "Physiotherapy",
      description: "Expert physiotherapy services to help patients recover movement and function after illness or injury.",
      imageUrl: "https://images.unsplash.com/photo-1628348070889-cb656235b4eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "Customized sessions"
    },
    {
      title: "Caregiver Services",
      description: "Compassionate caregivers provide assistance with daily activities, personal care, and companionship.",
      imageUrl: "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "Available 12/24 hours"
    },
    {
      title: "BSc Nursing",
      description: "Advanced nursing care provided by BSc qualified nurses for complex medical needs and specialized care.",
      imageUrl: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "Advanced care"
    },
    {
      title: "Babysitter Services",
      description: "Reliable and caring babysitters to ensure your child's well-being and safety while you're away.",
      imageUrl: "https://images.unsplash.com/photo-1588117305388-c2631a279f82?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "Flexible scheduling"
    },
    {
      title: "Ambulance Service",
      description: "Prompt and reliable ambulance services for emergency transport with trained medical staff.",
      imageUrl: "https://images.unsplash.com/photo-1587745415881-d60dbffd1d36?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300",
      availability: "24/7 availability"
    }
  ];

  return (
    <section id="services" className="py-16 bg-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary">Our Services</h2>
          <p className="text-foreground/70 mt-2 max-w-2xl mx-auto">
            Comprehensive healthcare services tailored to your specific needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition duration-300"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={service.imageUrl} 
                  alt={`${service.title} Services`}
                  className="w-full h-full object-cover transition duration-300 hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h3 className="font-poppins font-semibold text-xl mb-2 text-primary">{service.title}</h3>
                <p className="text-foreground/70 mb-4">{service.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-primary font-medium">{service.availability}</span>
                  <a 
                    href="#contact" 
                    className="text-accent hover:text-primary transition duration-300 font-medium"
                  >
                    Enquire Now
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
