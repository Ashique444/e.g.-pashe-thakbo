import React from "react";
import { Button } from "@/components/ui/button";

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800" 
                alt="Healthcare professionals" 
                className="rounded-2xl shadow-lg z-10 relative"
              />
              <div className="absolute -bottom-6 -right-6 bg-primary/10 w-48 h-48 rounded-2xl"></div>
              <div className="absolute -top-6 -left-6 bg-accent/10 w-32 h-32 rounded-2xl"></div>
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary mb-6">About Pashe Thakbo</h2>
            <p className="text-foreground/80 mb-4">
              Pashe Thakbo Nursing Home Care Service is dedicated to providing high-quality healthcare services in the comfort of your home. Our name "Pashe Thakbo" means "We will be by your side," which reflects our commitment to supporting you through every step of your healthcare journey.
            </p>
            <p className="text-foreground/80 mb-4">
              Founded with a vision to make quality healthcare accessible to everyone, we have grown to become one of the most trusted home care providers in Bangladesh. Our team consists of certified healthcare professionals who are not only skilled in their fields but also compassionate in their approach.
            </p>
            <p className="text-foreground/80 mb-6">
              We provide a wide range of services including nursing care, physiotherapy, caregiving, and more. Our service covers all of Bangladesh, ensuring that quality healthcare reaches every corner of the country.
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-light p-4 rounded-lg">
                <h4 className="font-poppins font-semibold text-primary">Our Mission</h4>
                <p className="text-sm text-foreground/70">
                  To provide compassionate and professional healthcare services that enhance the quality of life for our patients.
                </p>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <h4 className="font-poppins font-semibold text-primary">Our Vision</h4>
                <p className="text-sm text-foreground/70">
                  To be the most trusted home healthcare provider in Bangladesh, known for excellence and compassion.
                </p>
              </div>
            </div>
            
            <Button
              variant="round-primary"
              size="round-lg"
              asChild
            >
              <a href="#contact">Contact Us Today</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
