import React from "react";
import { CONTACT_NUMBER } from "@/lib/constants";
import { Phone, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Facebook, Youtube } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <img 
              src="https://i.ibb.co/n6TbPV0/pashe-thakbo-logo.png" 
              alt="Pashe Thakbo Logo" 
              className="h-16 mb-4 bg-white p-2 rounded-lg"
            />
            <p className="text-gray-300 mb-4">
              Professional nursing and home care services all across Bangladesh.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://www.facebook.com/pashethakbonursinghomecareservice" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-white transition duration-300"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="https://www.youtube.com/@PasheThakboNursingHomeCare" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-white transition duration-300"
                aria-label="YouTube"
              >
                <Youtube className="h-5 w-5" />
              </a>
              <a 
                href={`https://wa.me/${CONTACT_NUMBER}`}
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-white transition duration-300"
                aria-label="WhatsApp"
              >
                <FaWhatsapp className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Nursing Care
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Physiotherapy
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Caregiver Services
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  BSc Nursing
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Babysitter Services
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Ambulance Service
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-gray-300 hover:text-white transition duration-300">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="text-gray-300 hover:text-white transition duration-300">
                  About Us
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition duration-300">
                  Services
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-white transition duration-300">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-poppins font-semibold text-lg mb-4">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Phone className="h-5 w-5 mt-1 mr-3 text-primary" />
                <span>
                  <a href={`tel:${CONTACT_NUMBER}`} className="text-gray-300 hover:text-white transition duration-300">
                    {CONTACT_NUMBER}
                  </a>
                </span>
              </li>
              <li className="flex items-start">
                <Mail className="h-5 w-5 mt-1 mr-3 text-primary" />
                <span>
                  <a href="mailto:info@pashethakbo.com" className="text-gray-300 hover:text-white transition duration-300">
                    info@pashethakbo.com
                  </a>
                </span>
              </li>
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mt-1 mr-3 text-primary" />
                <span className="text-gray-300">
                  123 Health Avenue, Dhaka, Bangladesh
                </span>
              </li>
            </ul>
            <Button 
              variant="round-primary" 
              size="default" 
              asChild
              className="mt-4"
            >
              <a href={`tel:${CONTACT_NUMBER}`} className="flex items-center">
                <Phone className="mr-2 h-4 w-4" /> Call Now
              </a>
            </Button>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Pashe Thakbo Nursing Home Care Service. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
