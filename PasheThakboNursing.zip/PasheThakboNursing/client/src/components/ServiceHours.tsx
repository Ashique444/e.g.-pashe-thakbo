import React from "react";
import { Clock, Calendar, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CONTACT_NUMBER } from "@/lib/constants";
import { Phone } from "lucide-react";

const ServiceHours: React.FC = () => {
  return (
    <section className="py-12 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-md p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary mb-6">Service Hours</h2>
              <p className="mb-6 text-foreground/80">
                We understand that healthcare needs vary from person to person. That's why we offer flexible scheduling options to meet your specific requirements.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-poppins font-semibold text-lg">12-Hour Service</h3>
                    <p className="text-foreground/70">
                      Perfect for daytime assistance or overnight care, our 12-hour service provides focused support during specific periods.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-poppins font-semibold text-lg">24-Hour Service</h3>
                    <p className="text-foreground/70">
                      Round-the-clock care for patients who require continuous monitoring and assistance throughout the day and night.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-poppins font-semibold text-lg">Customized Schedules</h3>
                    <p className="text-foreground/70">
                      We can create personalized care schedules based on your unique needs and preferences.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col justify-center">
              <img 
                src="/assets/nurse-patient.jpg" 
                alt="Healthcare professional helping patient" 
                className="rounded-xl shadow-sm"
              />
              <div className="bg-primary text-white p-5 rounded-xl mt-6">
                <h3 className="font-poppins font-semibold text-xl mb-2">Need Assistance?</h3>
                <p className="mb-4">Our team is ready to help you determine the best care schedule for your needs.</p>
                <div className="flex space-x-4">
                  <Button
                    variant="default"
                    className="bg-white text-primary hover:bg-white/90"
                    asChild
                  >
                    <a href={`tel:${CONTACT_NUMBER}`} className="flex items-center">
                      <Phone className="mr-2 h-4 w-4" /> Call Now
                    </a>
                  </Button>
                  <Button
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-primary"
                    asChild
                  >
                    <a href="#contact">Contact Us</a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceHours;
