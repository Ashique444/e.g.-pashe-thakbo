import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CONTACT_NUMBER } from "@/lib/constants";
import { Phone } from "lucide-react";

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <img
                src="/assets/pashe-thakbo-logo.jpg" 
                alt="Pashe Thakbo Logo"
                className="h-12 md:h-16 cursor-pointer"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            <a 
              href="#home" 
              className="font-poppins font-medium text-primary hover:text-accent transition duration-300"
            >
              Home
            </a>
            <a 
              href="#services" 
              className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
            >
              Services
            </a>
            <a 
              href="#about" 
              className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
            >
              About Us
            </a>
            <a 
              href="#contact" 
              className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
            >
              Contact
            </a>
          </nav>

          {/* Contact Button (Desktop) */}
          <div className="hidden md:flex space-x-4">
            <Button 
              variant="round-primary" 
              size="default" 
              asChild
            >
              <a href={`tel:${CONTACT_NUMBER}`} className="flex items-center">
                <Phone className="mr-2 h-4 w-4" /> Call Now
              </a>
            </Button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={toggleMobileMenu}
            className="md:hidden text-foreground focus:outline-none"
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <a 
                href="#home" 
                className="font-poppins font-medium text-primary hover:text-accent transition duration-300"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </a>
              <a 
                href="#services" 
                className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Services
              </a>
              <a 
                href="#about" 
                className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About Us
              </a>
              <a 
                href="#contact" 
                className="font-poppins font-medium text-foreground hover:text-primary transition duration-300"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact
              </a>
              <Button 
                variant="round-primary" 
                size="default" 
                asChild
                className="justify-center"
              >
                <a href={`tel:${CONTACT_NUMBER}`} className="flex items-center">
                  <Phone className="mr-2 h-4 w-4" /> Call Now
                </a>
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
