import React from "react";
import { CONTACT_NUMBER } from "@/lib/constants";
import { FaFacebookF, FaYoutube, FaWhatsapp } from "react-icons/fa";

interface SocialLinksProps {
  position?: "fixed" | "absolute" | "relative";
}

const SocialLinks: React.FC<SocialLinksProps> = ({ position = "relative" }) => {
  const positionClasses = {
    fixed: "fixed right-5 top-1/3",
    absolute: "absolute right-5 top-1/3",
    relative: "relative"
  };

  return (
    <div className={`${positionClasses[position]} flex flex-col space-y-3 z-40`}>
      <a 
        href="https://www.facebook.com/pashethakbonursinghomecareservice" 
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:bg-primary hover:text-white transition duration-300 text-primary"
        aria-label="Facebook"
      >
        <FaFacebookF className="text-xl" />
      </a>
      <a 
        href="https://www.youtube.com/@PasheThakboNursingHomeCare" 
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:bg-primary hover:text-white transition duration-300 text-primary"
        aria-label="YouTube"
      >
        <FaYoutube className="text-xl" />
      </a>
      <a 
        href={`https://wa.me/${CONTACT_NUMBER}`}
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:bg-primary hover:text-white transition duration-300 text-primary"
        aria-label="WhatsApp"
      >
        <FaWhatsapp className="text-xl" />
      </a>
    </div>
  );
};

export default SocialLinks;
