import React from "react";
import { Award, Clock, MapPin, Heart } from "lucide-react";
import { Feature } from "@/lib/types";

const FeaturesSection: React.FC = () => {
  const features: Feature[] = [
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "Qualified Professionals",
      description: "Our team consists of certified and experienced healthcare professionals"
    },
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: "Flexible Hours",
      description: "Choose between 12-hour and 24-hour care services based on your needs"
    },
    {
      icon: <MapPin className="h-8 w-8 text-primary" />,
      title: "Nationwide Coverage",
      description: "We provide our services throughout Bangladesh for your convenience"
    },
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "Compassionate Care",
      description: "We treat every patient with dignity, respect, and heartfelt compassion"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary">Why Choose Pashe Thakbo?</h2>
          <p className="text-foreground/70 mt-2 max-w-2xl mx-auto">
            We are committed to providing the highest quality care services with compassion and professionalism
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-light rounded-xl p-6 text-center shadow-sm hover:shadow-md transition duration-300"
            >
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                {feature.icon}
              </div>
              <h3 className="font-poppins font-semibold text-xl mb-2">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
