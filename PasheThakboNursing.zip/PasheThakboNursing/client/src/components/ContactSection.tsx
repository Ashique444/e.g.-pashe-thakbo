import React from "react";
import ContactForm from "./ContactForm";
import { Phone, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CONTACT_NUMBER } from "@/lib/constants";
import { FaFacebookF, FaYoutube, FaWhatsapp } from "react-icons/fa";

const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary">Contact Us</h2>
          <p className="text-foreground/70 mt-2 max-w-2xl mx-auto">
            Reach out to us for any inquiries or to schedule a service
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <ContactForm />
          </div>
          
          <div className="space-y-8">
            <div className="bg-light p-6 rounded-xl">
              <h3 className="font-poppins font-semibold text-xl mb-4 text-primary">Get in Touch</h3>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium">Phone</h4>
                    <a 
                      href={`tel:${CONTACT_NUMBER}`} 
                      className="text-foreground hover:text-primary transition duration-300"
                    >
                      {CONTACT_NUMBER}
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium">Email</h4>
                    <a 
                      href="mailto:info@pashethakbo.com" 
                      className="text-foreground hover:text-primary transition duration-300"
                    >
                      info@pashethakbo.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-poppins font-medium">Office Address</h4>
                    <p className="text-foreground">
                      123 Health Avenue, Dhaka, Bangladesh
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-light p-6 rounded-xl">
              <h3 className="font-poppins font-semibold text-xl mb-4 text-primary">Connect With Us</h3>
              <p className="mb-4">Follow us on social media to stay updated with our latest services and health tips.</p>
              
              <div className="flex space-x-4">
                <a 
                  href="https://www.facebook.com/pashethakbonursinghomecareservice" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-sm hover:bg-primary hover:text-white transition duration-300 text-primary"
                  aria-label="Facebook"
                >
                  <FaFacebookF className="text-xl" />
                </a>
                <a 
                  href="https://www.youtube.com/@PasheThakboNursingHomeCare" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-sm hover:bg-primary hover:text-white transition duration-300 text-primary"
                  aria-label="YouTube"
                >
                  <FaYoutube className="text-xl" />
                </a>
                <a 
                  href={`https://wa.me/${CONTACT_NUMBER}`}
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-white w-12 h-12 rounded-full flex items-center justify-center shadow-sm hover:bg-primary hover:text-white transition duration-300 text-primary"
                  aria-label="WhatsApp"
                >
                  <FaWhatsapp className="text-xl" />
                </a>
              </div>
            </div>
            
            <div className="bg-primary text-white p-6 rounded-xl">
              <h3 className="font-poppins font-semibold text-xl mb-4">Service Coverage</h3>
              <p className="mb-4">We provide our services throughout Bangladesh, including all major cities and rural areas.</p>
              <p className="mb-4">No matter where you are located, our professional healthcare team can reach you.</p>
              <Button
                variant="default"
                className="bg-white text-primary hover:bg-white/90"
                asChild
              >
                <a href={`tel:${CONTACT_NUMBER}`} className="flex items-center">
                  <Phone className="mr-2 h-4 w-4" /> Call for Details
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
