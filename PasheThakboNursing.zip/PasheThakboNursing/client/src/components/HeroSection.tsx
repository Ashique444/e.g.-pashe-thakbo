import React from "react";
import { Button } from "@/components/ui/button";

const HeroSection: React.FC = () => {
  return (
    <section id="home" className="relative bg-gradient-to-r from-primary/10 to-secondary/10 overflow-hidden">
      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 space-y-4 md:pr-8 mb-8 md:mb-0">
            <h1 className="font-poppins font-bold text-3xl md:text-4xl lg:text-5xl text-primary">
              Professional Healthcare in the Comfort of Your Home
            </h1>
            <p className="text-lg md:text-xl text-foreground/80">
              Pashe Thakbo provides comprehensive nursing and care services all across Bangladesh with trusted professionals.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
              <Button
                variant="round-primary"
                size="round-lg"
                asChild
              >
                <a href="#services">Our Services</a>
              </Button>
              <Button
                variant="round-outline"
                size="round-lg"
                asChild
              >
                <a href="#contact">Contact Us</a>
              </Button>
            </div>
          </div>
          <div className="md:w-1/2">
            <img
              src="/assets/pashe-thakbo-banner.jpg"
              alt="Pashe Thakbo Care Services"
              className="rounded-2xl shadow-lg w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
