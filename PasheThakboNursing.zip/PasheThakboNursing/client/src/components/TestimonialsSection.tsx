import React from "react";
import { Testimonial } from "@/lib/types";
import { Star } from "lucide-react";

const TestimonialsSection: React.FC = () => {
  const testimonials: Testimonial[] = [
    {
      content: "The nursing staff from Pashe Thakbo provided exceptional care for my mother after her surgery. They were professional, compassionate, and attentive to all her needs. We couldn't be more grateful for their service.",
      author: "Rahat Khan",
      location: "Dhaka",
      initials: "RK",
      rating: 5
    },
    {
      content: "I hired a physiotherapist from Pashe Thakbo for my father's rehabilitation after his stroke. The improvement in his mobility has been remarkable. The therapist was knowledgeable and patient throughout the process.",
      author: "Sadia Ahmed",
      location: "Chittagong",
      initials: "SA",
      rating: 5
    },
    {
      content: "The caregiver assigned to my grandmother was incredibly kind and attentive. She helped with daily activities and provided much-needed companionship. Their 24-hour service option gave our family peace of mind.",
      author: "Mohammed Rahman",
      location: "Sylhet",
      initials: "MR",
      rating: 4.5
    }
  ];

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={`full-${i}`} className="fill-primary text-primary h-4 w-4" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <svg
          key="half-star"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-primary h-4 w-4"
        >
          <path className="fill-primary" d="M12 1.27L16.15 8.31L24 9.27L18 14.14L19.55 21.8L12 17.77V1.27Z" />
          <path d="M12 17.77L4.45 21.8L6 14.14L0 9.27L7.85 8.31L12 1.27V17.77Z" />
        </svg>
      );
    }

    // Add empty stars to make total of 5
    for (let i = Math.ceil(rating); i < 5; i++) {
      stars.push(
        <Star key={`empty-${i}`} className="text-primary h-4 w-4" />
      );
    }

    return stars;
  };

  return (
    <section className="py-16 bg-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-poppins font-bold text-2xl md:text-3xl text-primary">What Our Clients Say</h2>
          <p className="text-foreground/70 mt-2 max-w-2xl mx-auto">
            Read testimonials from families who have experienced our care services
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-md"
            >
              <div className="flex items-center mb-4">
                <div className="text-primary flex">
                  {renderStars(testimonial.rating)}
                </div>
              </div>
              <p className="text-foreground/80 italic mb-4">"{testimonial.content}"</p>
              <div className="flex items-center">
                <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mr-4">
                  <span className="font-poppins font-medium text-primary">{testimonial.initials}</span>
                </div>
                <div>
                  <h4 className="font-poppins font-semibold">{testimonial.author}</h4>
                  <p className="text-sm text-foreground/60">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
