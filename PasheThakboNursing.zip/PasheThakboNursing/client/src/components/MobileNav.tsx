import React from "react";
import { CONTACT_NUMBER } from "@/lib/constants";
import { FaFacebookF, FaWhatsapp, FaListUl, FaPhone } from "react-icons/fa";

const MobileNav: React.FC = () => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-lg rounded-t-2xl z-40">
      <div className="flex justify-around py-3">
        <a 
          href={`tel:${CONTACT_NUMBER}`} 
          className="flex flex-col items-center text-primary"
          aria-label="Call"
        >
          <FaPhone className="text-xl" />
          <span className="text-xs mt-1">Call</span>
        </a>
        <a 
          href={`https://wa.me/${CONTACT_NUMBER}`} 
          className="flex flex-col items-center text-primary"
          aria-label="WhatsApp"
        >
          <FaWhatsapp className="text-xl" />
          <span className="text-xs mt-1">WhatsApp</span>
        </a>
        <a 
          href="#services" 
          className="flex flex-col items-center text-primary"
          aria-label="Services"
        >
          <FaListUl className="text-xl" />
          <span className="text-xs mt-1">Services</span>
        </a>
        <a 
          href="https://www.facebook.com/pashethakbonursinghomecareservice" 
          className="flex flex-col items-center text-primary"
          aria-label="Facebook"
        >
          <FaFacebookF className="text-xl" />
          <span className="text-xs mt-1">Facebook</span>
        </a>
      </div>
    </div>
  );
};

export default MobileNav;
