import { ReactNode } from "react";

export interface Feature {
  icon: ReactNode;
  title: string;
  description: string;
}

export interface Service {
  title: string;
  description: string;
  imageUrl: string;
  availability: string;
}

export interface Testimonial {
  content: string;
  author: string;
  location: string;
  initials: string;
  rating: number;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}
