export const CONTACT_NUMBER = "01712543176";

export const SOCIAL_LINKS = {
  FACEBOOK: "https://www.facebook.com/pashethakbonursinghomecareservice",
  YOUTUBE: "https://www.youtube.com/@PasheThakboNursingHomeCare",
  WHATSAPP: `https://wa.me/01712543176`,
};
